#include <stdio.h>
#include "GSearch.cpp"
void main()
{
	AdjGraph *G;
	int A[][MAXVEX]={
		{ 0,  2, 5,  3, INF,INF,INF},
		{INF, 0, 2, INF,INF, 8, INF},
		{INF,INF,0, 1,  3,   5, INF},
		{INF,INF,INF,0, 5, INF,INF},
		{INF,INF,INF,INF, 0, 3,  9},
		{INF,INF,INF,INF,INF,0, 5},
		{INF,INF,INF,INF,INF,INF,0}};
	int n=7,e=12,i;
	CreateGraph(G,A,n,e);	//����ͼ���ڽӱ�
	printf("�ڽӱ�G:\n"); DispGraph(G);
	printf("v=0�ĸ��ֱ�������:\n");
	for (i=0;i<G->n;i++) visited[i]=0;
	printf("  DFS: "); DFS(G,0); printf("\n");
	for (i=0;i<G->n;i++) visited[i]=0;
	printf("  BFS: "); BFS(G,0); printf("\n");
	DestroyGraph(G);

	MatGraph g;
	CreateGraph(g,A,n,e);	//����ͼ���ڽӾ���
	printf("\n�ڽӾ���g:\n"); DispGraph(g);
	printf("v=0�ĸ��ֱ�������:\n");
	for (i=0;i<G->n;i++) visited[i]=0;
	printf("  DFS1: "); DFS1(g,0); printf("\n");
	for (i=0;i<G->n;i++) visited[i]=0;
	printf("  BFS1: "); BFS1(g,0); printf("\n");
	DestroyGraph(g);
}

