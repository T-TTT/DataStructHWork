#include <stdio.h>
void Trans(int a[],int n)	//ת���㷨
{	int i,j,c;
	for (i=n-1;i>=0;i--)
	{	c=0;
		for (j=0;j<i;j++)
			if (a[j]<a[i]) c++;
		a[i]=c;
	}
}
void main()
{
	int a[]={5,2,1,4,3};
	int n=sizeof(a)/sizeof(a[0]);
	printf("ת��ǰa:");
	for (int i=0;i<n;i++)
		printf("%3d",a[i]);
	printf("\n");
	Trans(a,n);
	printf("ת����a:");
	for (int j=0;j<n;j++)
		printf("%3d",a[j]);
	printf("\n");
}
