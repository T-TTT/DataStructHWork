#include <stdio.h>
#define N 4
int findk(int i,int j)				//��i,j��k
{	if (i<=j)
		return (j*(j+1)/2+i);
	else
		return (i*(i+1)/2+j);
}
int Compress(int A[N][N],int B[])	//��Aѹ���洢��B��
{
	int i,j,k=0;
	for (j=0;j<N;j++)
		for (i=0;i<=j;i++)
		{
			B[k]=A[i][j];
			k++;
		}
	return k;
}
void dispA(int B[])				//ͨ��B���A������Ԫ��
{
	for (int i=0;i<N;i++)
	{
		for (int j=0;j<N;j++)
			printf("%4d",B[findk(i,j)]);
		printf("\n");
	}

}
void dispB(int B[],int s)
{
	for (int k=0;k<s;k++)
		printf("%4d",B[k]);
	printf("\n");
}
void main()
{
	int A[4][4]={{1,2,3,4},{2,5,6,7},{3,6,8,9},{4,7,9,10}};
	int B[10];
	int s;					//B��Ԫ�ظ���
	printf("ԭ����A:\n");
	for (int i=0;i<N;i++)
	{
		for (int j=0;j<N;j++)
			printf("%4d",A[i][j]);
		printf("\n");
	}
	s=Compress(A,B);
	printf("���B:\n");
	dispB(B,s);
	printf("ͨ��B���A:\n");
	dispA(B);
}
