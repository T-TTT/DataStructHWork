#include "BST.cpp"
void ReOrder(BSTNode *bt)	//����㷨
{	if (bt!=NULL)
	{	ReOrder(bt->rchild);
		printf("%d ",bt->key);
		ReOrder(bt->lchild);
	}
}

void main()
{
	KeyType a[]={25,18,46,2,53,39,32,4,74,67,60,11};
	int n=12;
	BSTNode *bt;
	CreateBST(bt,a,n);
	printf("����������bt: ");
	DispBST(bt); printf("\n");
	printf("�ݼ�����: ");
	ReOrder(bt); printf("\n");
	DestroyBST(bt);
}

