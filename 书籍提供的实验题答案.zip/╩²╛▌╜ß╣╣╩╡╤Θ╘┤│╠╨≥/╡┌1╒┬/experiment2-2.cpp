#include <stdio.h>
typedef struct
{
	int a;		//ʵ��
	int b;		//�鲿
} Complex;		//������������
void CreateComplex(Complex &c,int i,int j)
{
	c.a=i;
	c.b=j;
}
void dispComplex(Complex c)
{
	printf("%d",c.a);
	if (c.b>=0)
		printf("+%di\n",c.b);
	else
		printf("-%di\n",-c.b);
}
void add(Complex c1,Complex c2,Complex &c3)
{
	c3.a=c1.a+c2.a;
	c3.b=c1.b+c2.b;
}
void sub(Complex c1,Complex c2,Complex &c3)
{
	c3.a=c1.a-c2.a;
	c3.b=c1.b-c2.b;
}
void mult(Complex c1,Complex c2,Complex &c3)
{
	c3.a=c1.a*c2.a-c1.b*c2.b;
	c3.b=c1.a*c2.b-c1.b*c2.a;
}

void main()
{
	Complex c1,c2,c3;
	CreateComplex(c1,1,2);
	CreateComplex(c2,5,-3);
	printf("c1: "); dispComplex(c1);
	printf("c2: "); dispComplex(c2);
	add(c1,c2,c3);
	printf("c1+c2: "); dispComplex(c3);
	sub(c1,c2,c3);
	printf("c1-c2: "); dispComplex(c3);
	mult(c1,c2,c3);
	printf("c1*c2: "); dispComplex(c3);
}
