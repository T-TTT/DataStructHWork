#include <stdio.h>
#include <time.h>		//��clock_t, clock, CLOCKS_PER_SEC
long Sum1(long n)		//�㷨1
{
	long s=0;
	for (long i=1;i<=n;i++)
		s+=i;
	return s;
}
long Sum2(long n)		//�㷨2
{
	long s=n*(n+1)/2;
	return s;
}
void display(long n)		//������Խ��
{
	long sum=0,i;
	clock_t t;
	printf("�㷨1: ");
	t=clock();
	for (i=1;i<=n;i++)
		sum+=Sum1(i);
	t=clock()-t;
	printf("���=%ld  ",sum);
	printf ("ʱ��=%lf��\n" ,((float)t)/CLOCKS_PER_SEC);
	sum=0;
	printf("�㷨2: ");
	t=clock();
	for (i=1;i<=n;i++)
		sum+=Sum2(i);
	t=clock()-t;
	printf("���=%ld  ",sum);
	printf ("ʱ��=%lf��\n" ,((float)t)/CLOCKS_PER_SEC);
}
void main()
{
	display(100000);
}
