#include <stdio.h>
void maxs(int a[],int n,int &max1,int &max2)
{
	int i;
	max1=max2=a[0];
	for (i=1;i<n;i++)
		if (a[i]>max1)
		{
			max2=max1;
			max1=a[i];
		}
		else if (a[i]>max2)
			max2=a[i];
}
void main()
{
	int a[]={1,4,10,6,8,3,5,7,9,2};
	int n=sizeof(a)/sizeof(a[0]);
	int max1,max2;
	printf("a�е�Ԫ��:");
	for (int i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\n");
	printf("�����Ԫ��max1,�δ�Ԫ��max2\n");
	maxs(a,n,max1,max2);
	printf("max1=%d, max2=%d\n",max1,max2);
}
