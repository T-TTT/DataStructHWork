#include <stdio.h>
#include <time.h>			//��clock_t, clock, CLOCKS_PER_SEC
#define MAX 999
long Product1(long n)		//�㷨1
{
	long p=0,p1;
	for (long i=1;i<=n;i++)
	{
		p1=1;
		for (long j=1;j<=i;j++)	//��j!
			p1*=j;
		p+=p1;
	}
	return p;
}
long Product2(long n)			//�㷨2
{
	long p=0,p1=1;
	for (long i=1;i<=n;i++)
	{
		p1*=i;
		p+=p1;
	}
	return p;
}
void display(long n)		//������Խ��
{
	long p;
	clock_t t;
	printf("�㷨1: ");
	t=clock();
	p=Product1(n);
	t=clock()-t;
	printf("���=%ld  ",p);
	printf ("ʱ��=%lf��\n" ,((float)t)/CLOCKS_PER_SEC);

	printf("�㷨2: ");
	t=clock();
	p=Product2(n);
	t=clock()-t;
	printf("���=%ld  ",p);
	printf ("ʱ��=%lf��\n" ,((float)t)/CLOCKS_PER_SEC);
}
void main()
{
	display(100000);
}
