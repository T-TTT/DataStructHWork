#include "SLinkNode.cpp"			//�����������������㺯��
void Union(SLinkNode *L1,SLinkNode *L2,SLinkNode *&L3)		//�󲢼�
{
	SLinkNode *p,*q,*s,*tc;
	L3=(SLinkNode *)malloc(sizeof(SLinkNode));
	tc=L3;
	p=L1->next;
	q=L2->next;
	while (p!=NULL && q!=NULL)
	{
		if (p->data<q->data)
		{
			s=(SLinkNode *)malloc(sizeof(SLinkNode));
			s->data=p->data;
			tc->next=s; tc=s;
			p=p->next;
		}
		else if (p->data>q->data)
		{
			s=(SLinkNode *)malloc(sizeof(SLinkNode));
			s->data=q->data;
			tc->next=s; tc=s;
			q=q->next;
		}
		else
		{
			s=(SLinkNode *)malloc(sizeof(SLinkNode));
			s->data=p->data;
			tc->next=s; tc=s;
			p=p->next;
			q=q->next;
		}
	}
	while (p!=NULL)
	{
		s=(SLinkNode *)malloc(sizeof(SLinkNode));
		s->data=p->data;
		tc->next=s;	tc=s;
		p=p->next;
	}
	while (q!=NULL)
	{
		s=(SLinkNode *)malloc(sizeof(SLinkNode));
		s->data=q->data;
		tc->next=s;	tc=s;
		q=q->next;
	}
	tc->next=NULL;
}
void InterSection(SLinkNode *L1,SLinkNode *L2,SLinkNode *&L3)		//�󽻼�
{
	SLinkNode *p,*q,*s,*tc;
	L3=(SLinkNode *)malloc(sizeof(SLinkNode));
	tc=L3;
	p=L1->next;
	q=L2->next;
	while (p!=NULL && q!=NULL)
	{
		if (p->data<q->data)
			p=p->next;
		else if (p->data>q->data)
			q=q->next;
		else							//p->data=q->data
		{
			s=(SLinkNode *)malloc(sizeof(SLinkNode));
			s->data=p->data;
			tc->next=s;
			tc=s;
			p=p->next;
			q=q->next;
		}
	}
	tc->next=NULL;
}
void Subs(SLinkNode *L1,SLinkNode *L2,SLinkNode *&L3) //��
{
	SLinkNode *p,*q,*s,*tc;
	L3=(SLinkNode *)malloc(sizeof(SLinkNode));
	tc=L3;
	p=L1->next;
	q=L2->next;
	while (p!=NULL && q!=NULL)
	{
		if (p->data<q->data)
		{
			s=(SLinkNode *)malloc(sizeof(SLinkNode));
			s->data=p->data;
			tc->next=s;
			tc=s;
			p=p->next;
		}
		else if (p->data>q->data)
			q=q->next;
		else						//p->data=q->data
		{
			p=p->next;
			q=q->next;
		}
	}
	while (p!=NULL)
	{
		s=(SLinkNode *)malloc(sizeof(SLinkNode));
		s->data=p->data;
		tc->next=s;
		tc=s;
		p=p->next;
	}
	tc->next=NULL;
}
void main()
{
	SLinkNode *A,*B,*C,*D,*E;
	ElemType a[]={1,3,6,8,10,20};
	CreateListR(A,a,6);				//β�巨����
	printf("����A:");DispList(A);
	ElemType b[]={2,5,6,10,16,20,30};
	CreateListR(B,b,7);				//β�巨����
	printf("����B:");DispList(B);
	printf("��A��B����C\n");
	Union(A,B,C);					//��A��B����C
	printf("����C:");DispList(C);
	printf("��A��B����C\n");
	InterSection(A,B,D);			//��A��B����D
	printf("����D:");DispList(D);
	printf("��A��B�E\n");
	Subs(A,B,E);					//��A��B�E
	printf("����E:");DispList(E);
	DestroyList(A);
	DestroyList(B);
	DestroyList(C);
	DestroyList(D);
	DestroyList(E);
}
