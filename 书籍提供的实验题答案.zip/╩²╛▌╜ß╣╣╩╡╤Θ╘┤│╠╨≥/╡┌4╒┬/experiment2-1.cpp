#include <stdio.h>
#include "SqString.cpp"					//����˳�򴮵Ļ������㺯��
void Reverse(SqString &s)
{
	int i=0,j=s.length-1;
	char tmp;
	while (i<j)
	{
		tmp=s.data[i];
		s.data[i]=s.data[j];
		s.data[j]=tmp;
		i++; j--;
	}
}
void main()
{
	SqString s;
	Assign(s,"1234abcde");
	printf("s: ");DispStr(s);
	printf("����s\n");
	Reverse(s);
	printf("s: ");DispStr(s);
	DestroyStr(s);
}

